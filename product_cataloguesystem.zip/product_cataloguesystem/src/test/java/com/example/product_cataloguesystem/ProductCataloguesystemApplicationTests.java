package com.example.product_cataloguesystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductCataloguesystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
